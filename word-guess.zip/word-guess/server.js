const express = require('express');
const app = express();
/*
const words = require('./word');
const homepage = require('./homepage');
*/
app.use(express.static('./public'));
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
const login = require('./login.js'); // "chat" holds all the non-web logic for managing users/messages
const game = require('./game.js'); // "chat-web" holds the templates for the generated HTML

app.get('/', function(req,res){
    res.sendFile(__dirname + "/public/login.html");
});

app.get('/game', function(req,res){
    res.send(game.guessPage(guess));
});

app.post('/game', express.urlencoded({ extended: false }), (req, res) => {
  const sender = req.body.username;
  const text = req.body.text;
  const timestamp = new Date();
  chat.addMessage(sender, timestamp, text);
  res.redirect('/');
});

app.listen(3000, () => {
  console.log('listening on http://localhost:3000');
});
