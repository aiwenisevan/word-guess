
const secretWord = "Tea";

const turn = {};


function compare(word, guess) {  // DO NOT MODIFY
  //console.log();
  word = word.toLocaleLowerCase();
  guess = guess.toLocaleLowerCase();
  //guess = guess.;
  const visited = [];
  let counter = 0;
  for (let letter of word) {
    for (let index = 0; index < guess.length; index++) {
      //only when the common letter's index has not been added before
      //it will be counted as another valid common letter
      //this is to avoid repititions of countering for same letter,e.g: too, two
      if (visited.includes(index)===false && guess[index]===letter){
        visited.push(index);
        counter ++;
        //so it won't continue looping for repitions e.g:two, too
        break;
      }
    }
  }
  return counter;
}

// const wordList = [
//   {
//     guessedWord: "Amit",
//     rightChar: new Date("2019-01-01 19:20:00"),
//     turns: "You up?",
//   }
// ];

const wordList = [
  {
    guessedWord: "Amit",
    rightChar: new Date("2019-01-01 19:20:00"),
    turns: "You up?",
  }
];

const historyDict = {};
const answerDict = {};
const userDict={};

historyDict['0000'] = wordList;
answerDict['0000'] = 'Tea';
userDict['Aiwen'] = '0000';
turn['0000']=0;

function addWords(guessedWord, rightChar, turns, id) {
  historyDict[id].push({guessedWord: guessedWord, rightChar: rightChar, turns: turns[id]});
}

const helper = {
  userDict,
  historyDict,
  answerDict,
  turn,
  addWords,
  compare
};

module.exports = helper;
