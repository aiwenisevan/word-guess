
const validList = ["TEA", "EAT", "TEE"]

const word = {
  validList
};

module.exports = word;
