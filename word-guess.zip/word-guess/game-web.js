const gameWeb = {
  guessPage: function(helper, word, id) {
    return `
    <!DOCTYPE html>
    <html lang="en" dir="ltr">
      <head>
        <meta charset="utf-8">
        <title>Guess A Word</title
        <link rel="stylesheet" href="style.css">
      </head>
      <body>helper
        <h1>Guess The Right Word!</h1>
        <ul>
          <li>TEA</li>
          <li>ATE</li>
          <li>TEE</li>
        </ul>
        <p>Try and guess the word untill you are right!</p>
          <div class="displayField">
            ${gameWeb.getOutgoing()}
          </div>
          <div id="showResults">
            <p >Previous Guesses: <span class="guesses"></span></p>
          </div>
           ${gameWeb.getMessageList(helper, id)}
      </body>
    </html>
  `;
  },
  getMessageList: function(helper, id) {
    return `<ol class="messages">` +
    helper.historyDict[id].map( cur => `
      <li>
        <div class="cur">
          <p >Previous Guesses</p>
          <span class="guessedWord">"tried word :" + ${cur.guessedWord}</span>
          <span class="rightChar">"matches :" + ${cur.rightChar}</span>
          <span class="turns">"turns :" ${cur.turns}</span>
        </div>
      </li>
    `).join('') +
    `</ol>`;
  },

  getOutgoing: function() {
    return   `<form class="" action="/game" method="post">
             <input type="text" name="guessWord">
             <input type="submit" id="subt" value="Submit guess" class="guessSubmit">
             </form>`;
  }
};

module.exports = gameWeb;
