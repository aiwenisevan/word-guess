const gameWeb = {
  guessPage: function(game) {
    return `
    <!DOCTYPE html>
    <html lang="en" dir="ltr">
      <head>
        <meta charset="utf-8">
        <title>Guess A Word</title
        <link rel="stylesheet" href="style.css">
      </head>
      <body>
        <h1>Guess The Right Word!</h1>
        <p>Try and guess the word untill you are right!</p>

        <div class="displayField">
          <form class="" action="/game" method="post">
            <input type="text" name="guessWord">
            <input type="submit" id="subt" value="Submit guess" class="guessSubmit">
          </form>
          <div id="showResults">
            <p >Previous Guesses: <span class="guesses"></span></p>
          </div>
        </div>
      </body>
    </html>
  `;
  },

  getWordList: function(chat) {
    return `<ol class="messages">` +
    chat.messages.map( message => `
      <li>
        <div class="message">
          <span class="sender">${chat.users[message.sender]}</span>
          <span class="timestamp">${message.timestamp}</span>
          <span class="text">${message.text}</span>
        </div>
      </li>
    `).join('') +
    `</ol>`;
  },


  getInput: function() {
    return `<form action="/game" method="POST">
            <input name="username" type="hidden" value="Bao">
            <label>Type <input id="type-area" type="text" name="text"></label>
            <button id="send-btn" type="submit">Send</button>
            </form>`;
  }
};

module.exports = chatWeb;
