const users = {
    "Amit": "Amit",
    "Bao": "Bao",
};

const wordList = [
  {
    sender: "Amit",
    timestamp: new Date("2019-01-01 19:20:00"),
    text: "You up?",
  }
];

function addWords(guessedWord, rightChar, turns) {
  messages.push({guessedWord: guessedWord, rightChar: rightChar, turns: turns});
}

const word = {
  guessedWord,
  rightChar,turns
  turns,
};

module.exports = word;
